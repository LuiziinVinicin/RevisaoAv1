﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoAV1Tests
{
    public class Fibonacci
    {
        public int CalculoFibonacci(int posicao)
        {
            if (posicao < 0)
                throw new ArgumentException("A posição na sequência de Fibonacci não pode ser negativa.");

            if (posicao == 0)
                return 0;
            else if (posicao == 1)
                return 1;

            int anterior = 0;
            int atual = 1;
            for (int i = 2; i <= posicao; i++)
            {
                int proximo = anterior + atual;
                anterior = atual;
                atual = proximo;
            }
            return atual;
        }
    }
}
