﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RevisaoAV1Tests
{
    public class Fatorial
    {
        public int CalculoFatorial(int num)
        {
            if (num < 0)
                throw new ArgumentException("O fatorial de números negativos não é definido.");

            if (num == 0)
                return 1;

            int resultado = 1;
            for (int i = 1; i <= num; i++)
            {
                resultado *= i;
            }
            return resultado;
        }
    }
}
